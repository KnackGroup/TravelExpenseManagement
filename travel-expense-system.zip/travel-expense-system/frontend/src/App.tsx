import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import Layout from './components/Layout';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import TourPlansPage from './pages/TourPlansPage';
import AdvancesPage from './pages/AdvancesPage';
import ExpenseReportsPage from './pages/ExpenseReportsPage';
import DailyReportsPage from './pages/DailyReportsPage';
import ReconciliationPage from './pages/ReconciliationPage';
import AdminHierarchyPage from './pages/AdminHierarchyPage';
import AdminPolicyPage from './pages/AdminPolicyPage';
import AdminNotificationsPage from './pages/AdminNotificationsPage';
import AdminAiSettingsPage from './pages/AdminAiSettingsPage';

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route
            element={
              <ProtectedRoute>
                <Layout />
              </ProtectedRoute>
            }
          >
            <Route path="/" element={<DashboardPage />} />
            <Route path="/tour-plans" element={<TourPlansPage />} />
            <Route path="/advances" element={<AdvancesPage />} />
            <Route path="/expense-reports" element={<ExpenseReportsPage />} />
            <Route path="/daily-reports" element={<DailyReportsPage />} />
            <Route path="/reconciliation" element={<ReconciliationPage />} />
            <Route path="/admin/hierarchy" element={<AdminHierarchyPage />} />
            <Route path="/admin/policy" element={<AdminPolicyPage />} />
            <Route path="/admin/notifications" element={<AdminNotificationsPage />} />
            <Route path="/admin/ai" element={<AdminAiSettingsPage />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}
