import { useState } from 'react';
import { apiClient, apiErrorMessage } from '../api/client';
import { useAuth } from '../context/AuthContext';
import type { PolicyAnswer } from '../api/types';

/** Grounded policy Q&A - answers come straight from the PolicyCaps table, not a generic
 * LLM, so there's no hallucination risk on "am I allowed to book a flight". Works with zero
 * AI configuration. */
export default function PolicyAssistant() {
  const { employee } = useAuth();
  const [question, setQuestion] = useState('');
  const [history, setHistory] = useState<{ q: string; a: string }[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function ask(e: React.FormEvent) {
    e.preventDefault();
    if (!question.trim() || !employee) return;
    setBusy(true);
    setError(null);
    try {
      const res = await apiClient.post<PolicyAnswer>('/api/ai/policy-assistant/ask', {
        question,
        roleId: employee.roleId,
      });
      setHistory((h) => [...h, { q: question, a: res.data.answer }]);
      setQuestion('');
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="panel policy-assistant">
      <h2>Policy Assistant</h2>
      <p className="subtitle" style={{ marginBottom: 10 }}>
        Ask about your travel policy - answers are pulled directly from the configured caps for your role, so they're always accurate.
      </p>
      {history.length > 0 && (
        <div className="assistant-history">
          {history.map((h, i) => (
            <div key={i} className="assistant-turn">
              <div className="assistant-q">You: {h.q}</div>
              <div className="assistant-a">{h.a}</div>
            </div>
          ))}
        </div>
      )}
      {error && <div className="error-box">{error}</div>}
      <form onSubmit={ask} className="assistant-form">
        <input
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="e.g. Can I book a flight? What's my hotel cap?"
        />
        <button className="btn-primary" type="submit" disabled={busy}>{busy ? 'Asking…' : 'Ask'}</button>
      </form>
    </div>
  );
}
