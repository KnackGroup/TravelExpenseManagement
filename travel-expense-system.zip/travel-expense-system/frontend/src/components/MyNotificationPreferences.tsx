import { useEffect, useState } from 'react';
import { apiClient } from '../api/client';
import type { NotificationPreference } from '../api/types';

/** Self-service "whether to send email or not" toggle per event type, layered on top of the
 * admin's global on/off switch for that event (Admin > Notifications > Templates). */
export default function MyNotificationPreferences() {
  const [prefs, setPrefs] = useState<NotificationPreference[]>([]);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    apiClient.get<NotificationPreference[]>('/api/notifications/preferences').then((r) => setPrefs(r.data));
  }, []);

  async function toggle(eventType: string, isEnabled: boolean) {
    setPrefs((prev) => prev.map((p) => (p.eventType === eventType ? { ...p, isEnabledForMe: isEnabled } : p)));
    await apiClient.put('/api/notifications/preferences', { eventType, isEnabled });
  }

  if (prefs.length === 0) return null;

  return (
    <div className="panel">
      <div className="page-header">
        <h2>My email notifications</h2>
        <button className="btn-link" onClick={() => setOpen((v) => !v)}>{open ? 'Hide' : 'Manage'}</button>
      </div>
      {open && (
        <table className="data-table">
          <thead><tr><th>Event</th><th>Send me an email?</th></tr></thead>
          <tbody>
            {prefs.map((p) => (
              <tr key={p.eventType}>
                <td>{p.description ?? p.eventType}{!p.globallyEnabled && <span className="tag" style={{ marginLeft: 8 }}>disabled system-wide</span>}</td>
                <td>
                  <label className="switch-label">
                    <input
                      type="checkbox"
                      checked={p.isEnabledForMe}
                      disabled={!p.globallyEnabled}
                      onChange={(e) => toggle(p.eventType, e.target.checked)}
                    />
                    {p.isEnabledForMe ? 'On' : 'Off'}
                  </label>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
