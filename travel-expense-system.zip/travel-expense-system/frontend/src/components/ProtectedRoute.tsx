import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { employee, isLoading } = useAuth();

  if (isLoading) return <div className="page-loading">Loading…</div>;
  if (!employee) return <Navigate to="/login" replace />;

  return <>{children}</>;
}
