import { NavLink, Outlet } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Layout() {
  const { employee, logout } = useAuth();
  if (!employee) return null;

  const isAdmin = employee.roleType === 'Admin';
  const isAccounts = employee.roleType === 'Accounts';
  const isSales = employee.roleType === 'Sales';

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">Travel &amp; Expense</div>
        <nav>
          <NavLink to="/" end>Dashboard</NavLink>
          {isSales && <NavLink to="/tour-plans">Tour Plans</NavLink>}
          {(isSales || isAccounts) && <NavLink to="/advances">Advances</NavLink>}
          {isSales && <NavLink to="/expense-reports">Expense Reports</NavLink>}
          {isSales && <NavLink to="/daily-reports">Daily Reports</NavLink>}
          <NavLink to="/reconciliation">Reconciliation</NavLink>
          {isAdmin && <NavLink to="/admin/hierarchy">Admin: Hierarchy</NavLink>}
          {isAdmin && <NavLink to="/admin/policy">Admin: Policy</NavLink>}
          {isAdmin && <NavLink to="/admin/notifications">Admin: Notifications</NavLink>}
          {isAdmin && <NavLink to="/admin/ai">Admin: AI Settings</NavLink>}
        </nav>
        <div className="sidebar-footer">
          <div className="who">
            <div className="who-name">{employee.fullName}</div>
            <div className="who-role">{employee.roleName}{employee.channelName ? ` · ${employee.channelName}` : ''}</div>
          </div>
          <button className="btn-link" onClick={logout}>Sign out</button>
        </div>
      </aside>
      <main className="content">
        <Outlet />
      </main>
    </div>
  );
}
