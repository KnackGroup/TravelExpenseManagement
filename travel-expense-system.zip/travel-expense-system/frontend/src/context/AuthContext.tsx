import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { apiClient } from '../api/client';
import type { EmployeeSummary } from '../api/types';

interface AuthContextValue {
  employee: EmployeeSummary | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [employee, setEmployee] = useState<EmployeeSummary | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem('te_employee');
    const token = localStorage.getItem('te_token');
    if (stored && token) {
      setEmployee(JSON.parse(stored));
    }
    setIsLoading(false);
  }, []);

  async function login(email: string, password: string) {
    const res = await apiClient.post('/api/auth/login', { email, password });
    const { token, employee: emp } = res.data;
    localStorage.setItem('te_token', token);
    localStorage.setItem('te_employee', JSON.stringify(emp));
    setEmployee(emp);
  }

  function logout() {
    localStorage.removeItem('te_token');
    localStorage.removeItem('te_employee');
    setEmployee(null);
  }

  const value = useMemo(() => ({ employee, isLoading, login, logout }), [employee, isLoading]);

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
