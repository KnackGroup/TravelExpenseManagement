import { useEffect, useState } from 'react';
import { apiClient, apiErrorMessage } from '../api/client';
import type { ExpenseCategory, PolicyCap, Role } from '../api/types';

export default function AdminPolicyPage() {
  const [roles, setRoles] = useState<Role[]>([]);
  const [categories, setCategories] = useState<ExpenseCategory[]>([]);
  const [caps, setCaps] = useState<PolicyCap[]>([]);
  const [selectedRoleId, setSelectedRoleId] = useState<number | ''>('');
  const [error, setError] = useState<string | null>(null);

  const [categoryId, setCategoryId] = useState<number | ''>('');
  const [isAllowed, setIsAllowed] = useState(true);
  const [maxPerDay, setMaxPerDay] = useState('');
  const [maxPerBooking, setMaxPerBooking] = useState('');
  const [maxClass, setMaxClass] = useState('');
  const [effectiveFrom, setEffectiveFrom] = useState(new Date().toISOString().slice(0, 10));

  useEffect(() => {
    apiClient.get<Role[]>('/api/hierarchy/roles').then((r) => setRoles(r.data.filter((x) => x.roleType === 'Sales')));
    apiClient.get<ExpenseCategory[]>('/api/policy/categories').then((r) => setCategories(r.data));
  }, []);

  function loadCaps(roleId: number) {
    apiClient.get<PolicyCap[]>(`/api/policy/caps?roleId=${roleId}`).then((r) => setCaps(r.data));
  }

  useEffect(() => { if (selectedRoleId) loadCaps(selectedRoleId); }, [selectedRoleId]);

  async function saveCap(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await apiClient.post('/api/policy/caps', {
        roleId: selectedRoleId,
        expenseCategoryId: categoryId,
        isAllowed,
        maxAmountPerDay: maxPerDay ? Number(maxPerDay) : null,
        maxAmountPerBooking: maxPerBooking ? Number(maxPerBooking) : null,
        maxClass: maxClass || null,
        currency: 'INR',
        effectiveFrom,
        effectiveTo: null,
      });
      setCategoryId(''); setMaxPerDay(''); setMaxPerBooking(''); setMaxClass(''); setIsAllowed(true);
      if (selectedRoleId) loadCaps(selectedRoleId);
    } catch (err) { setError(apiErrorMessage(err)); }
  }

  return (
    <div>
      <h1>Admin · Travel Policy</h1>
      <p className="subtitle">Per-role, per-expense-category caps and flight/train eligibility - the entire travel policy engine. Changes here apply immediately to new expense submissions, with full history preserved.</p>
      {error && <div className="error-box">{error}</div>}

      <label>Role</label>
      <select value={selectedRoleId} onChange={(e) => setSelectedRoleId(Number(e.target.value))}>
        <option value="">Select a role…</option>
        {roles.map((r) => <option key={r.roleId} value={r.roleId}>{r.roleName}{r.channelName ? ` (${r.channelName})` : ''}</option>)}
      </select>

      {selectedRoleId && (
        <>
          <div className="panel">
            <h2>Current caps</h2>
            <table className="data-table">
              <thead><tr><th>Category</th><th>Allowed</th><th>Max / Day</th><th>Max / Booking</th><th>Class</th><th>Effective</th></tr></thead>
              <tbody>
                {caps.map((c) => (
                  <tr key={c.policyCapId}>
                    <td>{c.categoryName}</td>
                    <td>{c.isAllowed ? 'Yes' : <span className="tag tag-exception">No</span>}</td>
                    <td>{c.maxAmountPerDay != null ? `₹${c.maxAmountPerDay.toLocaleString('en-IN')}` : '—'}</td>
                    <td>{c.maxAmountPerBooking != null ? `₹${c.maxAmountPerBooking.toLocaleString('en-IN')}` : '—'}</td>
                    <td>{c.maxClass ?? '—'}</td>
                    <td>{c.effectiveFrom} {c.effectiveTo ? `→ ${c.effectiveTo}` : '(current)'}</td>
                  </tr>
                ))}
                {caps.length === 0 && <tr><td colSpan={6} className="empty-row">No policy configured yet for this role.</td></tr>}
              </tbody>
            </table>
          </div>

          <div className="panel">
            <h2>Set / update a cap</h2>
            <form className="form-grid" onSubmit={saveCap}>
              <div>
                <label>Category</label>
                <select value={categoryId} onChange={(e) => setCategoryId(Number(e.target.value))} required>
                  <option value="">Select…</option>
                  {categories.map((c) => <option key={c.expenseCategoryId} value={c.expenseCategoryId}>{c.categoryName}</option>)}
                </select>
              </div>
              <div>
                <label>Allowed for this role?</label>
                <select value={isAllowed ? 'yes' : 'no'} onChange={(e) => setIsAllowed(e.target.value === 'yes')}>
                  <option value="yes">Yes</option>
                  <option value="no">No (e.g. Area Manager - no flights)</option>
                </select>
              </div>
              <div><label>Max per day (₹)</label><input type="number" value={maxPerDay} onChange={(e) => setMaxPerDay(e.target.value)} /></div>
              <div><label>Max per booking (₹) — flight/train</label><input type="number" value={maxPerBooking} onChange={(e) => setMaxPerBooking(e.target.value)} /></div>
              <div><label>Max class (optional)</label><input value={maxClass} onChange={(e) => setMaxClass(e.target.value)} placeholder="e.g. Economy, AC-2Tier, Cab" /></div>
              <div><label>Effective from</label><input type="date" value={effectiveFrom} onChange={(e) => setEffectiveFrom(e.target.value)} required /></div>
              <div style={{ alignSelf: 'end' }}><button className="btn-primary" type="submit">Save Cap</button></div>
            </form>
          </div>
        </>
      )}
    </div>
  );
}
