import { useEffect, useState } from 'react';
import { apiClient, apiErrorMessage } from '../api/client';
import type { Channel, EmployeeListItem, Role } from '../api/types';

export default function AdminHierarchyPage() {
  const [channels, setChannels] = useState<Channel[]>([]);
  const [roles, setRoles] = useState<Role[]>([]);
  const [employees, setEmployees] = useState<EmployeeListItem[]>([]);
  const [error, setError] = useState<string | null>(null);

  const [roleChannelId, setRoleChannelId] = useState<string>('');
  const [roleCode, setRoleCode] = useState('');
  const [roleName, setRoleName] = useState('');
  const [roleLevel, setRoleLevel] = useState('');
  const [roleType, setRoleType] = useState('Sales');

  const [empCode, setEmpCode] = useState('');
  const [empName, setEmpName] = useState('');
  const [empEmail, setEmpEmail] = useState('');
  const [empPassword, setEmpPassword] = useState('');
  const [empRoleId, setEmpRoleId] = useState<number | ''>('');
  const [empManagerId, setEmpManagerId] = useState<number | ''>('');

  function load() {
    apiClient.get<Channel[]>('/api/hierarchy/channels').then((r) => setChannels(r.data));
    apiClient.get<Role[]>('/api/hierarchy/roles').then((r) => setRoles(r.data));
    apiClient.get<EmployeeListItem[]>('/api/hierarchy/employees').then((r) => setEmployees(r.data));
  }
  useEffect(load, []);

  async function createRole(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await apiClient.post('/api/hierarchy/roles', {
        channelId: roleChannelId ? Number(roleChannelId) : null,
        roleCode, roleName,
        hierarchyLevel: roleLevel ? Number(roleLevel) : null,
        roleType,
      });
      setRoleCode(''); setRoleName(''); setRoleLevel('');
      load();
    } catch (err) { setError(apiErrorMessage(err)); }
  }

  async function createEmployee(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await apiClient.post('/api/hierarchy/employees', {
        employeeCode: empCode, fullName: empName, email: empEmail, password: empPassword,
        roleId: empRoleId, managerEmployeeId: empManagerId || null,
      });
      setEmpCode(''); setEmpName(''); setEmpEmail(''); setEmpPassword(''); setEmpRoleId(''); setEmpManagerId('');
      load();
    } catch (err) { setError(apiErrorMessage(err)); }
  }

  return (
    <div>
      <h1>Admin · Hierarchy</h1>
      <p className="subtitle">Channels, roles (the dynamic GM / Continent Manager / Regional Manager / Area Manager levels), and employees with their reporting manager.</p>
      {error && <div className="error-box">{error}</div>}

      <div className="panel">
        <h2>Roles</h2>
        <table className="data-table">
          <thead><tr><th>Channel</th><th>Code</th><th>Name</th><th>Level</th><th>Type</th></tr></thead>
          <tbody>
            {roles.map((r) => (
              <tr key={r.roleId}>
                <td>{r.channelName ?? '—'}</td>
                <td>{r.roleCode}</td>
                <td>{r.roleName}</td>
                <td>{r.hierarchyLevel ?? '—'}</td>
                <td>{r.roleType}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <h3>Add a role / hierarchy level</h3>
        <form className="form-grid" onSubmit={createRole}>
          <div>
            <label>Channel (blank = cross-channel)</label>
            <select value={roleChannelId} onChange={(e) => setRoleChannelId(e.target.value)}>
              <option value="">—</option>
              {channels.map((c) => <option key={c.channelId} value={c.channelId}>{c.channelName}</option>)}
            </select>
          </div>
          <div><label>Code</label><input value={roleCode} onChange={(e) => setRoleCode(e.target.value)} required /></div>
          <div><label>Name</label><input value={roleName} onChange={(e) => setRoleName(e.target.value)} required /></div>
          <div><label>Level (1 = top)</label><input type="number" value={roleLevel} onChange={(e) => setRoleLevel(e.target.value)} /></div>
          <div>
            <label>Type</label>
            <select value={roleType} onChange={(e) => setRoleType(e.target.value)}>
              <option value="Sales">Sales</option>
              <option value="Accounts">Accounts</option>
              <option value="Admin">Admin</option>
            </select>
          </div>
          <div style={{ alignSelf: 'end' }}><button className="btn-primary" type="submit">Add Role</button></div>
        </form>
      </div>

      <div className="panel">
        <h2>Employees</h2>
        <table className="data-table">
          <thead><tr><th>Code</th><th>Name</th><th>Email</th><th>Role</th><th>Channel</th><th>Manager</th></tr></thead>
          <tbody>
            {employees.map((e) => (
              <tr key={e.employeeId}>
                <td>{e.employeeCode}</td>
                <td>{e.fullName}</td>
                <td>{e.email}</td>
                <td>{e.roleName}</td>
                <td>{e.channelName ?? '—'}</td>
                <td>{e.managerName ?? '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <h3>Add an employee</h3>
        <form className="form-grid" onSubmit={createEmployee}>
          <div><label>Code</label><input value={empCode} onChange={(e) => setEmpCode(e.target.value)} required /></div>
          <div><label>Full Name</label><input value={empName} onChange={(e) => setEmpName(e.target.value)} required /></div>
          <div><label>Email</label><input type="email" value={empEmail} onChange={(e) => setEmpEmail(e.target.value)} required /></div>
          <div><label>Temp Password</label><input value={empPassword} onChange={(e) => setEmpPassword(e.target.value)} required /></div>
          <div>
            <label>Role</label>
            <select value={empRoleId} onChange={(e) => setEmpRoleId(Number(e.target.value))} required>
              <option value="">Select…</option>
              {roles.map((r) => <option key={r.roleId} value={r.roleId}>{r.roleName}{r.channelName ? ` (${r.channelName})` : ''}</option>)}
            </select>
          </div>
          <div>
            <label>Reports To</label>
            <select value={empManagerId} onChange={(e) => setEmpManagerId(Number(e.target.value))}>
              <option value="">— none —</option>
              {employees.map((e) => <option key={e.employeeId} value={e.employeeId}>{e.fullName} ({e.roleName})</option>)}
            </select>
          </div>
          <div style={{ alignSelf: 'end' }}><button className="btn-primary" type="submit">Add Employee</button></div>
        </form>
      </div>
    </div>
  );
}
