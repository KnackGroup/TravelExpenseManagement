import { useEffect, useState } from 'react';
import { apiClient, apiErrorMessage } from '../api/client';
import type { EmailSettings, EmailTemplate } from '../api/types';

export default function AdminNotificationsPage() {
  const [settings, setSettings] = useState<EmailSettings | null>(null);
  const [newSecret, setNewSecret] = useState('');
  const [testAddress, setTestAddress] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  const [templates, setTemplates] = useState<EmailTemplate[]>([]);
  const [editingEvent, setEditingEvent] = useState<string | null>(null);
  const [draftSubject, setDraftSubject] = useState('');
  const [draftBody, setDraftBody] = useState('');
  const [draftEnabled, setDraftEnabled] = useState(true);

  function load() {
    apiClient.get<EmailSettings>('/api/notifications/settings').then((r) => setSettings(r.data));
    apiClient.get<EmailTemplate[]>('/api/notifications/templates').then((r) => setTemplates(r.data));
  }
  useEffect(load, []);

  async function saveSettings(e: React.FormEvent) {
    e.preventDefault();
    if (!settings) return;
    setError(null);
    setMessage(null);
    try {
      await apiClient.put('/api/notifications/settings', { ...settings, newSecret: newSecret || null });
      setNewSecret('');
      setMessage('Email settings saved.');
      load();
    } catch (err) {
      setError(apiErrorMessage(err));
    }
  }

  async function testSend() {
    if (!testAddress) return;
    setError(null);
    setMessage(null);
    try {
      await apiClient.post('/api/notifications/settings/test-send', { toAddress: testAddress });
      setMessage(`Test email sent to ${testAddress}.`);
    } catch (err) {
      setError(apiErrorMessage(err));
    }
  }

  function startEdit(t: EmailTemplate) {
    setEditingEvent(t.eventType);
    setDraftSubject(t.subject);
    setDraftBody(t.bodyHtml);
    setDraftEnabled(t.isEnabled);
  }

  async function saveTemplate() {
    if (!editingEvent) return;
    setError(null);
    try {
      await apiClient.put(`/api/notifications/templates/${editingEvent}`, {
        subject: draftSubject, bodyHtml: draftBody, isEnabled: draftEnabled,
      });
      setEditingEvent(null);
      load();
    } catch (err) {
      setError(apiErrorMessage(err));
    }
  }

  if (!settings) return <div className="page-loading">Loading…</div>;

  return (
    <div>
      <h1>Admin · Notifications</h1>
      <p className="subtitle">Configure Outlook/Microsoft 365 SMTP, and edit what each workflow event emails out. Changes apply immediately - no redeploy.</p>

      {error && <div className="error-box">{error}</div>}
      {message && <div className="tag tag-ok" style={{ display: 'inline-block', marginBottom: 16 }}>{message}</div>}

      <div className="panel">
        <h2>SMTP settings</h2>
        <form onSubmit={saveSettings}>
          <div className="form-grid">
            <div>
              <label>Enabled</label>
              <select value={settings.isEnabled ? 'yes' : 'no'} onChange={(e) => setSettings({ ...settings, isEnabled: e.target.value === 'yes' })}>
                <option value="no">Off</option>
                <option value="yes">On</option>
              </select>
            </div>
            <div>
              <label>Auth mode</label>
              <select value={settings.authMode} onChange={(e) => setSettings({ ...settings, authMode: e.target.value as EmailSettings['authMode'] })}>
                <option value="Basic">Basic (SMTP AUTH username/app password)</option>
                <option value="OAuth2">OAuth2 (app registration, client credentials)</option>
              </select>
            </div>
            <div>
              <label>SMTP host</label>
              <input value={settings.smtpHost} onChange={(e) => setSettings({ ...settings, smtpHost: e.target.value })} />
            </div>
            <div>
              <label>SMTP port</label>
              <input type="number" value={settings.smtpPort} onChange={(e) => setSettings({ ...settings, smtpPort: Number(e.target.value) })} />
            </div>
            <div>
              <label>{settings.authMode === 'OAuth2' ? 'App (client) ID' : 'SMTP username / mailbox'}</label>
              <input value={settings.smtpUsername ?? ''} onChange={(e) => setSettings({ ...settings, smtpUsername: e.target.value })} />
            </div>
            <div>
              <label>{settings.authMode === 'OAuth2' ? 'Client secret' : 'App password'} {settings.hasSecret && <span className="tag tag-ok">saved</span>}</label>
              <input type="password" placeholder={settings.hasSecret ? 'Leave blank to keep current' : ''} value={newSecret} onChange={(e) => setNewSecret(e.target.value)} />
            </div>
            {settings.authMode === 'OAuth2' && (
              <div>
                <label>Azure AD tenant ID</label>
                <input value={settings.oAuthTenantId ?? ''} onChange={(e) => setSettings({ ...settings, oAuthTenantId: e.target.value })} />
              </div>
            )}
            <div>
              <label>From address</label>
              <input type="email" value={settings.fromAddress} onChange={(e) => setSettings({ ...settings, fromAddress: e.target.value })} />
            </div>
            <div>
              <label>From name</label>
              <input value={settings.fromName} onChange={(e) => setSettings({ ...settings, fromName: e.target.value })} />
            </div>
          </div>
          <div style={{ marginTop: 12 }}>
            <button className="btn-primary" type="submit">Save SMTP Settings</button>
          </div>
        </form>

        <h3>Test send</h3>
        <div className="form-grid">
          <input type="email" placeholder="you@company.com" value={testAddress} onChange={(e) => setTestAddress(e.target.value)} />
          <button className="btn-small" onClick={testSend} type="button">Send test email</button>
        </div>

        <p className="subtitle" style={{ marginTop: 14, fontSize: '0.8rem' }}>
          OAuth2 mode requires your Exchange admin to grant this app's registration the SMTP.SendAsApp role for the
          sending mailbox first (Exchange Online PowerShell: New-ServicePrincipal / New-ManagementRoleAssignment) -
          see the README for the exact steps. Basic mode requires SMTP AUTH to be enabled for the mailbox.
        </p>
      </div>

      <div className="panel">
        <h2>Email templates</h2>
        <table className="data-table">
          <thead><tr><th>Event</th><th>Subject</th><th>Enabled</th><th></th></tr></thead>
          <tbody>
            {templates.map((t) => (
              <tr key={t.eventType}>
                <td>{t.description ?? t.eventType}</td>
                <td>{t.subject}</td>
                <td>{t.isEnabled ? 'Yes' : <span className="tag tag-exception">No</span>}</td>
                <td><button className="btn-small" onClick={() => startEdit(t)}>Edit</button></td>
              </tr>
            ))}
          </tbody>
        </table>

        {editingEvent && (
          <div className="panel" style={{ marginTop: 16, background: '#fafbfc' }}>
            <h3>Editing: {editingEvent}</h3>
            <label>Enabled</label>
            <select value={draftEnabled ? 'yes' : 'no'} onChange={(e) => setDraftEnabled(e.target.value === 'yes')}>
              <option value="yes">Yes</option>
              <option value="no">No</option>
            </select>
            <label>Subject</label>
            <input value={draftSubject} onChange={(e) => setDraftSubject(e.target.value)} />
            <label>Body (HTML, supports {'{{Placeholder}}'} tokens)</label>
            <textarea value={draftBody} onChange={(e) => setDraftBody(e.target.value)} rows={8} />
            <div style={{ marginTop: 10 }}>
              <button className="btn-primary" onClick={saveTemplate}>Save Template</button>{' '}
              <button className="btn-link" onClick={() => setEditingEvent(null)}>Cancel</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
