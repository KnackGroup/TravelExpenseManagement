import { useEffect, useState } from 'react';
import { apiClient, apiErrorMessage } from '../api/client';
import { useAuth } from '../context/AuthContext';
import type { AiFeatureStatus, Channel, ParseTourPlanTextResult, TourPlan, TourPlanStop } from '../api/types';

const emptyStop: TourPlanStop = { visitDate: '', location: '', stateOrCountry: '', purposeNotes: '' };

export default function TourPlansPage() {
  const { employee } = useAuth();
  const [plans, setPlans] = useState<TourPlan[]>([]);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [aiStatus, setAiStatus] = useState<AiFeatureStatus | null>(null);

  const [channelId, setChannelId] = useState<number | ''>('');
  const [title, setTitle] = useState('');
  const [purpose, setPurpose] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [stops, setStops] = useState<TourPlanStop[]>([{ ...emptyStop }]);

  const [nlText, setNlText] = useState('');
  const [nlBusy, setNlBusy] = useState(false);
  const [nlNote, setNlNote] = useState<string | null>(null);

  function load() {
    apiClient.get<TourPlan[]>('/api/tour-plans').then((r) => setPlans(r.data)).catch((e) => setError(apiErrorMessage(e)));
  }

  useEffect(() => {
    load();
    apiClient.get<Channel[]>('/api/hierarchy/channels').then((r) => {
      setChannels(r.data);
      if (employee?.channelId) setChannelId(employee.channelId);
    });
    apiClient.get<AiFeatureStatus>('/api/ai/status').then((r) => setAiStatus(r.data)).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function updateStop(idx: number, patch: Partial<TourPlanStop>) {
    setStops((prev) => prev.map((s, i) => (i === idx ? { ...s, ...patch } : s)));
  }

  async function parseWithAi() {
    if (!nlText.trim()) return;
    setNlBusy(true);
    setNlNote(null);
    try {
      const res = await apiClient.post<ParseTourPlanTextResult>('/api/ai/tour-plans/parse-text', { text: nlText });
      const parsed = res.data;
      if (!parsed.isAvailable) {
        setNlNote(parsed.notes ?? 'AI parsing is not available right now.');
        return;
      }
      if (parsed.title) setTitle(parsed.title);
      if (parsed.purposeOfVisit) setPurpose(parsed.purposeOfVisit);
      if (parsed.startDate) setStartDate(parsed.startDate);
      if (parsed.endDate) setEndDate(parsed.endDate);
      if (parsed.stops.length > 0) {
        setStops(parsed.stops.map((s) => ({
          visitDate: s.visitDate ?? '',
          location: s.location,
          stateOrCountry: s.stateOrCountry ?? '',
          purposeNotes: s.purposeNotes ?? '',
        })));
      }
      setNlNote('Filled in below from your description - review and adjust before submitting.');
    } catch (err) {
      setNlNote(apiErrorMessage(err));
    } finally {
      setNlBusy(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await apiClient.post('/api/tour-plans', {
        channelId,
        title,
        purposeOfVisit: purpose,
        startDate,
        endDate,
        stops: stops.filter((s) => s.location && s.visitDate),
      });
      setShowForm(false);
      setTitle('');
      setPurpose('');
      setStartDate('');
      setEndDate('');
      setStops([{ ...emptyStop }]);
      load();
    } catch (err) {
      setError(apiErrorMessage(err));
    }
  }

  return (
    <div>
      <div className="page-header">
        <h1>Tour Plans</h1>
        <button className="btn-primary" onClick={() => setShowForm((v) => !v)}>
          {showForm ? 'Cancel' : '+ New Tour Plan'}
        </button>
      </div>

      {error && <div className="error-box">{error}</div>}

      {showForm && (
        <form className="panel" onSubmit={handleSubmit}>
          {aiStatus?.isEnabled && (
            <div className="ai-quick-entry">
              <label>Quick entry with AI (optional)</label>
              <textarea
                value={nlText}
                onChange={(e) => setNlText(e.target.value)}
                rows={2}
                placeholder="e.g. 4 day trip to Gurugram, Noida and Ghaziabad starting Aug 25 for distributor visits and new retail onboarding"
              />
              <button type="button" className="btn-small" disabled={nlBusy} onClick={parseWithAi}>
                {nlBusy ? 'Parsing…' : '✨ Fill form with AI'}
              </button>
              {nlNote && <span className="ai-quick-entry-note">{nlNote}</span>}
            </div>
          )}

          <div className="form-grid">
            <div>
              <label>Channel</label>
              <select value={channelId} onChange={(e) => setChannelId(Number(e.target.value))} required>
                <option value="">Select…</option>
                {channels.map((c) => (
                  <option key={c.channelId} value={c.channelId}>{c.channelName}</option>
                ))}
              </select>
            </div>
            <div>
              <label>Title</label>
              <input value={title} onChange={(e) => setTitle(e.target.value)} required />
            </div>
            <div>
              <label>Start Date</label>
              <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} required />
            </div>
            <div>
              <label>End Date</label>
              <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} required />
            </div>
          </div>
          <label>Purpose of visit</label>
          <textarea value={purpose} onChange={(e) => setPurpose(e.target.value)} rows={2} />

          <h3>Stops</h3>
          {stops.map((s, idx) => (
            <div className="form-grid stop-row" key={idx}>
              <input type="date" value={s.visitDate} onChange={(e) => updateStop(idx, { visitDate: e.target.value })} />
              <input placeholder="Location" value={s.location} onChange={(e) => updateStop(idx, { location: e.target.value })} />
              <input placeholder="State / Country" value={s.stateOrCountry ?? ''} onChange={(e) => updateStop(idx, { stateOrCountry: e.target.value })} />
              <input placeholder="Purpose" value={s.purposeNotes ?? ''} onChange={(e) => updateStop(idx, { purposeNotes: e.target.value })} />
            </div>
          ))}
          <button type="button" className="btn-link" onClick={() => setStops((p) => [...p, { ...emptyStop }])}>
            + Add stop
          </button>

          <div>
            <button className="btn-primary" type="submit">Submit Tour Plan</button>
          </div>
        </form>
      )}

      <table className="data-table">
        <thead>
          <tr>
            <th>Title</th>
            <th>Channel</th>
            <th>Dates</th>
            <th>Status</th>
            <th>Stops</th>
          </tr>
        </thead>
        <tbody>
          {plans.map((p) => (
            <tr key={p.tourPlanId}>
              <td>{p.title}</td>
              <td>{p.channelName}</td>
              <td>{p.startDate} → {p.endDate}</td>
              <td><span className={`badge badge-${p.status.toLowerCase()}`}>{p.status}</span></td>
              <td>{p.stops.map((s) => s.location).join(', ')}</td>
            </tr>
          ))}
          {plans.length === 0 && (
            <tr><td colSpan={5} className="empty-row">No tour plans yet.</td></tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
