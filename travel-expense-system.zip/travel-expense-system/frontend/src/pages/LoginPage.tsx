import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { apiErrorMessage } from '../api/client';

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('am.delhi@knackpackaging.com');
  const [password, setPassword] = useState('Passw0rd!');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await login(email, password);
      navigate('/');
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="login-page">
      <form className="login-card" onSubmit={handleSubmit}>
        <h1>Travel &amp; Expense</h1>
        <p className="subtitle">Sales tour plan, advance &amp; expense management</p>

        <label>Email</label>
        <input value={email} onChange={(e) => setEmail(e.target.value)} type="email" required />

        <label>Password</label>
        <input value={password} onChange={(e) => setPassword(e.target.value)} type="password" required />

        {error && <div className="error-box">{error}</div>}

        <button className="btn-primary" type="submit" disabled={busy}>
          {busy ? 'Signing in…' : 'Sign in'}
        </button>

        <p className="hint">
          Demo accounts (password <code>Passw0rd!</code>): am.delhi@knackpackaging.com,
          rm.north@knackpackaging.com, gm.domestic@knackpackaging.com, am.uae@knackpackaging.com,
          rm.gulf@knackpackaging.com, cm.mea@knackpackaging.com, gm.export@knackpackaging.com,
          accounts@knackpackaging.com, admin@knackpackaging.com
        </p>
      </form>
    </div>
  );
}
