import { useEffect, useMemo, useState } from 'react';
import { apiClient, apiErrorMessage } from '../api/client';
import { useAuth } from '../context/AuthContext';
import type { AnomalyFlag, ExceptionRiskAssessment, ExpenseCategory, ExpenseReport, PolicyCap, ReceiptParseResult, TourPlan } from '../api/types';

interface DraftLine {
  expenseDate: string;
  expenseCategoryId: number | '';
  description: string;
  claimedAmount: string;
  currency: string;
}

const emptyLine: DraftLine = { expenseDate: '', expenseCategoryId: '', description: '', claimedAmount: '', currency: 'INR' };

/** Client-side mirror of the server's PolicyEngine, used only to highlight likely
 * exceptions live as the user types - the server re-checks authoritatively on submit. */
function evaluateDraft(line: DraftLine, caps: PolicyCap[], categories: ExpenseCategory[]) {
  if (!line.expenseCategoryId || !line.claimedAmount) return null;
  const category = categories.find((c) => c.expenseCategoryId === line.expenseCategoryId);
  const cap = caps.find((c) => c.expenseCategoryId === line.expenseCategoryId);
  if (!category) return null;
  if (!cap) return { isException: true, reason: 'No policy configured for this category.' };
  if (!cap.isAllowed) return { isException: true, reason: `${category.categoryName} is not permitted for your role.` };

  const amount = Number(line.claimedAmount);
  const relevant = category.isTicketCategory ? cap.maxAmountPerBooking : cap.maxAmountPerDay;
  if (relevant != null && amount > relevant) {
    const unit = category.isTicketCategory ? 'per-booking' : 'per-day';
    return { isException: true, reason: `Exceeds ${unit} cap of ₹${relevant.toLocaleString('en-IN')}${cap.maxClass ? ` (${cap.maxClass})` : ''}.` };
  }
  return { isException: false, reason: null };
}

export default function ExpenseReportsPage() {
  const { employee } = useAuth();
  const isSales = employee?.roleType === 'Sales';

  const [reports, setReports] = useState<ExpenseReport[]>([]);
  const [inbox, setInbox] = useState<ExpenseReport[]>([]);
  const [tourPlans, setTourPlans] = useState<TourPlan[]>([]);
  const [categories, setCategories] = useState<ExpenseCategory[]>([]);
  const [caps, setCaps] = useState<PolicyCap[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);

  const [tourPlanId, setTourPlanId] = useState<number | ''>('');
  const [lines, setLines] = useState<DraftLine[]>([{ ...emptyLine }]);
  const [scanningIdx, setScanningIdx] = useState<number | null>(null);
  const [riskByLineId, setRiskByLineId] = useState<Record<number, ExceptionRiskAssessment>>({});
  const [anomaliesByReportId, setAnomaliesByReportId] = useState<Record<number, AnomalyFlag[]>>({});

  function load() {
    if (isSales) apiClient.get<ExpenseReport[]>('/api/expense-reports').then((r) => {
      setReports(r.data);
      r.data.forEach((report) => {
        apiClient.get<AnomalyFlag[]>(`/api/ai/insights/anomalies/${report.expenseReportId}`)
          .then((res) => setAnomaliesByReportId((prev) => ({ ...prev, [report.expenseReportId]: res.data })))
          .catch(() => {});
      });
    });
    apiClient.get<ExpenseReport[]>('/api/expense-reports/inbox').then((r) => {
      setInbox(r.data);
      r.data.forEach((report) => {
        report.lineItems.filter((li) => li.isPolicyException && li.lineStatus === 'Pending').forEach((li) => {
          apiClient.get<ExceptionRiskAssessment>(`/api/ai/insights/exception/${li.expenseLineItemId}`)
            .then((res) => setRiskByLineId((prev) => ({ ...prev, [li.expenseLineItemId]: res.data })))
            .catch(() => {});
        });
      });
    }).catch(() => {});
    if (isSales) apiClient.get<TourPlan[]>('/api/tour-plans').then((r) => setTourPlans(r.data));
    apiClient.get<ExpenseCategory[]>('/api/policy/categories').then((r) => setCategories(r.data));
    if (employee) apiClient.get(`/api/policy/matrix/${employee.roleId}`).then((r) => setCaps(r.data.caps));
  }

  useEffect(load, [isSales]); // eslint-disable-line react-hooks/exhaustive-deps

  async function scanReceipt(idx: number, file: File) {
    setScanningIdx(idx);
    setError(null);
    try {
      const form = new FormData();
      form.append('file', file);
      const res = await apiClient.post<ReceiptParseResult>('/api/ai/receipts/parse', form);
      const parsed = res.data;
      if (!parsed.isAvailable) {
        setError(parsed.notes ?? 'Receipt scanning is not available right now.');
        return;
      }
      const matchedCategory = parsed.suggestedCategoryCode
        ? categories.find((c) => c.categoryCode === parsed.suggestedCategoryCode)
        : undefined;
      updateLine(idx, {
        expenseDate: parsed.expenseDate ?? lines[idx].expenseDate,
        claimedAmount: parsed.amount != null ? String(parsed.amount) : lines[idx].claimedAmount,
        description: parsed.vendor ?? lines[idx].description,
        expenseCategoryId: matchedCategory ? matchedCategory.expenseCategoryId : lines[idx].expenseCategoryId,
      });
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setScanningIdx(null);
    }
  }

  function updateLine(idx: number, patch: Partial<DraftLine>) {
    setLines((prev) => prev.map((l, i) => (i === idx ? { ...l, ...patch } : l)));
  }

  const evaluations = useMemo(() => lines.map((l) => evaluateDraft(l, caps, categories)), [lines, caps, categories]);
  const anyException = evaluations.some((e) => e?.isException);
  const total = lines.reduce((sum, l) => sum + (Number(l.claimedAmount) || 0), 0);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await apiClient.post('/api/expense-reports', {
        tourPlanId,
        lineItems: lines
          .filter((l) => l.expenseCategoryId && l.claimedAmount && l.expenseDate)
          .map((l) => ({
            expenseDate: l.expenseDate,
            expenseCategoryId: l.expenseCategoryId,
            description: l.description,
            claimedAmount: Number(l.claimedAmount),
            currency: l.currency,
          })),
      });
      setShowForm(false);
      setLines([{ ...emptyLine }]);
      load();
    } catch (err) {
      setError(apiErrorMessage(err));
    }
  }

  async function decideLine(reportId: number, lineItemId: number, approve: boolean) {
    setError(null);
    try {
      await apiClient.post(`/api/expense-reports/${reportId}/decide`, {
        decisions: [{ expenseLineItemId: lineItemId, approve, comments: approve ? 'Approved' : 'Rejected' }],
      });
      load();
    } catch (err) {
      setError(apiErrorMessage(err));
    }
  }

  return (
    <div>
      <div className="page-header">
        <h1>Expense Reports</h1>
        {isSales && (
          <button className="btn-primary" onClick={() => setShowForm((v) => !v)}>
            {showForm ? 'Cancel' : '+ Submit Expense Report'}
          </button>
        )}
      </div>

      {error && <div className="error-box">{error}</div>}

      {showForm && (
        <form className="panel" onSubmit={submit}>
          <label>Tour Plan</label>
          <select value={tourPlanId} onChange={(e) => setTourPlanId(Number(e.target.value))} required>
            <option value="">Select…</option>
            {tourPlans.map((p) => (
              <option key={p.tourPlanId} value={p.tourPlanId}>{p.title} ({p.startDate} → {p.endDate})</option>
            ))}
          </select>

          <h3>Line items</h3>
          <p className="subtitle" style={{ margin: '0 0 8px' }}>Tip: scan a receipt photo to auto-fill a line with AI (date, amount, vendor, category) - or just type it in manually.</p>
          <table className="data-table draft-table">
            <thead>
              <tr><th>Date</th><th>Category</th><th>Description</th><th>Amount (₹)</th><th>Receipt</th><th>Policy check</th></tr>
            </thead>
            <tbody>
              {lines.map((line, idx) => {
                const evalResult = evaluations[idx];
                return (
                  <tr key={idx} className={evalResult?.isException ? 'row-exception' : undefined}>
                    <td><input type="date" value={line.expenseDate} onChange={(e) => updateLine(idx, { expenseDate: e.target.value })} /></td>
                    <td>
                      <select value={line.expenseCategoryId} onChange={(e) => updateLine(idx, { expenseCategoryId: Number(e.target.value) })}>
                        <option value="">Select…</option>
                        {categories.map((c) => <option key={c.expenseCategoryId} value={c.expenseCategoryId}>{c.categoryName}</option>)}
                      </select>
                    </td>
                    <td><input value={line.description} onChange={(e) => updateLine(idx, { description: e.target.value })} /></td>
                    <td><input type="number" min="0" value={line.claimedAmount} onChange={(e) => updateLine(idx, { claimedAmount: e.target.value })} /></td>
                    <td>
                      <label className="btn-small receipt-upload-label">
                        {scanningIdx === idx ? 'Scanning…' : '📷 Scan'}
                        <input
                          type="file"
                          accept="image/*"
                          style={{ display: 'none' }}
                          disabled={scanningIdx !== null}
                          onChange={(e) => { const f = e.target.files?.[0]; if (f) scanReceipt(idx, f); e.target.value = ''; }}
                        />
                      </label>
                    </td>
                    <td className="policy-cell">
                      {evalResult == null ? '' : evalResult.isException
                        ? <span className="tag tag-exception">⚠ {evalResult.reason}</span>
                        : <span className="tag tag-ok">Within policy</span>}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          <button type="button" className="btn-link" onClick={() => setLines((p) => [...p, { ...emptyLine }])}>+ Add line</button>

          <div className="draft-total">
            Total claimed: <strong>₹{total.toLocaleString('en-IN')}</strong>
            {anyException && <span className="tag tag-exception" style={{ marginLeft: 12 }}>This report contains policy exceptions - it can still be submitted, and will be routed to your reporting manager for a decision on those lines.</span>}
          </div>

          <button className="btn-primary" type="submit">Submit Expense Report</button>
        </form>
      )}

      {inbox.length > 0 && (
        <div className="panel">
          <h2>Reports awaiting your decision (policy exceptions)</h2>
          {inbox.map((r) => (
            <div key={r.expenseReportId} className="inbox-report">
              <div className="inbox-report-header">
                <strong>{r.employeeName}</strong> — {r.tourPlanTitle} — Total ₹{r.totalClaimedAmount.toLocaleString('en-IN')}
              </div>
              <table className="data-table">
                <thead><tr><th>Date</th><th>Category</th><th>Amount</th><th>Reason</th><th>AI risk</th><th>Status</th><th>Action</th></tr></thead>
                <tbody>
                  {r.lineItems.filter((li) => li.isPolicyException).map((li) => {
                    const risk = riskByLineId[li.expenseLineItemId];
                    return (
                      <tr key={li.expenseLineItemId} className="row-exception">
                        <td>{li.expenseDate}</td>
                        <td>{li.categoryName}</td>
                        <td>₹{li.claimedAmount.toLocaleString('en-IN')}</td>
                        <td>{li.exceptionReason}</td>
                        <td>
                          {risk && (
                            <span className={`risk-badge risk-${risk.riskLevel.toLowerCase()}`} title={risk.rationale}>
                              {risk.riskLevel} · {risk.recommendation}
                            </span>
                          )}
                        </td>
                        <td><span className={`badge badge-${li.lineStatus.toLowerCase()}`}>{li.lineStatus}</span></td>
                        <td className="actions-cell">
                          {li.lineStatus === 'Pending' && (
                            <>
                              <button className="btn-small" onClick={() => decideLine(r.expenseReportId, li.expenseLineItemId, true)}>Approve</button>
                              <button className="btn-small btn-danger" onClick={() => decideLine(r.expenseReportId, li.expenseLineItemId, false)}>Reject</button>
                            </>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ))}
        </div>
      )}

      {isSales && (
        <div className="panel">
          <h2>My Expense Reports</h2>
          {reports.map((r) => {
            const anomalies = anomaliesByReportId[r.expenseReportId] ?? [];
            return (
            <div key={r.expenseReportId} className="inbox-report">
              <div className="inbox-report-header">
                {r.tourPlanTitle} — <span className={`badge badge-${r.status.toLowerCase()}`}>{r.status}</span>
                {' '}— Claimed ₹{r.totalClaimedAmount.toLocaleString('en-IN')} / Approved ₹{(r.totalApprovedAmount ?? 0).toLocaleString('en-IN')}
              </div>
              {anomalies.length > 0 && (
                <div className="anomaly-flags">
                  {anomalies.map((a, i) => (
                    <span key={i} className={`tag tag-exception anomaly-${a.severity.toLowerCase()}`}>🔍 {a.message}</span>
                  ))}
                </div>
              )}
              <table className="data-table">
                <thead><tr><th>Date</th><th>Category</th><th>Amount</th><th>Status</th><th>Note</th></tr></thead>
                <tbody>
                  {r.lineItems.map((li) => (
                    <tr key={li.expenseLineItemId} className={li.isPolicyException ? 'row-exception' : undefined}>
                      <td>{li.expenseDate}</td>
                      <td>{li.categoryName}</td>
                      <td>₹{li.claimedAmount.toLocaleString('en-IN')}</td>
                      <td><span className={`badge badge-${li.lineStatus.toLowerCase()}`}>{li.lineStatus}</span></td>
                      <td>{li.isPolicyException ? li.exceptionReason : ''}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            );
          })}
          {reports.length === 0 && <p className="empty-row">No expense reports yet.</p>}
        </div>
      )}
    </div>
  );
}
