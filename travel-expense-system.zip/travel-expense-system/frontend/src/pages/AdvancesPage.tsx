import { useEffect, useState } from 'react';
import { apiClient, apiErrorMessage } from '../api/client';
import { useAuth } from '../context/AuthContext';
import type { AdvanceRequestDto, AdvanceSuggestion, TourPlan } from '../api/types';

export default function AdvancesPage() {
  const { employee } = useAuth();
  const isSales = employee?.roleType === 'Sales';
  const isAccounts = employee?.roleType === 'Accounts';

  const [mine, setMine] = useState<AdvanceRequestDto[]>([]);
  const [inbox, setInbox] = useState<AdvanceRequestDto[]>([]);
  const [tourPlans, setTourPlans] = useState<TourPlan[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [showForm, setShowForm] = useState(false);

  const [tourPlanId, setTourPlanId] = useState<number | ''>('');
  const [amount, setAmount] = useState('');
  const [notes, setNotes] = useState('');
  const [suggestion, setSuggestion] = useState<AdvanceSuggestion | null>(null);

  function load() {
    if (isSales) apiClient.get<AdvanceRequestDto[]>('/api/advances').then((r) => setMine(r.data));
    apiClient.get<AdvanceRequestDto[]>('/api/advances/inbox').then((r) => setInbox(r.data)).catch(() => {});
    if (isSales) apiClient.get<TourPlan[]>('/api/tour-plans').then((r) => setTourPlans(r.data));
  }

  useEffect(load, [isSales]);

  useEffect(() => {
    setSuggestion(null);
    if (!tourPlanId) return;
    apiClient.get<AdvanceSuggestion>(`/api/ai/insights/advance-suggestion/${tourPlanId}`)
      .then((r) => setSuggestion(r.data))
      .catch(() => {});
  }, [tourPlanId]);

  async function submitRequest(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await apiClient.post('/api/advances', { tourPlanId, requestedAmount: Number(amount), requestNotes: notes });
      setShowForm(false);
      setAmount('');
      setNotes('');
      load();
    } catch (err) {
      setError(apiErrorMessage(err));
    }
  }

  async function decide(a: AdvanceRequestDto, approve: boolean) {
    setError(null);
    try {
      const endpoint = isAccounts ? 'decide/accounts' : 'decide/superior';
      await apiClient.post(`/api/advances/${a.advanceRequestId}/${endpoint}`, { approve, comments: approve ? 'Approved' : 'Rejected' });
      load();
    } catch (err) {
      setError(apiErrorMessage(err));
    }
  }

  async function disburse(a: AdvanceRequestDto) {
    setError(null);
    try {
      await apiClient.post(`/api/advances/${a.advanceRequestId}/disburse`, {
        disbursementMode: 'BankTransfer',
        amount: a.requestedAmount,
        referenceNo: `MANUAL-${Date.now()}`,
      });
      load();
    } catch (err) {
      setError(apiErrorMessage(err));
    }
  }

  return (
    <div>
      <div className="page-header">
        <h1>Advances</h1>
        {isSales && (
          <button className="btn-primary" onClick={() => setShowForm((v) => !v)}>
            {showForm ? 'Cancel' : '+ Request Advance'}
          </button>
        )}
      </div>

      {error && <div className="error-box">{error}</div>}

      {showForm && (
        <form className="panel" onSubmit={submitRequest}>
          <div className="form-grid">
            <div>
              <label>Tour Plan</label>
              <select value={tourPlanId} onChange={(e) => setTourPlanId(Number(e.target.value))} required>
                <option value="">Select…</option>
                {tourPlans.map((p) => (
                  <option key={p.tourPlanId} value={p.tourPlanId}>{p.title} ({p.startDate} → {p.endDate})</option>
                ))}
              </select>
            </div>
            <div>
              <label>Requested Amount (₹)</label>
              <input type="number" min="0" step="1" value={amount} onChange={(e) => setAmount(e.target.value)} required />
            </div>
          </div>

          {suggestion && (
            <div className="ai-suggestion">
              <span className="tag tag-ok">AI suggestion</span>{' '}
              ₹{suggestion.suggestedAmount.toLocaleString('en-IN')} — {suggestion.basis}
              {' '}
              <button type="button" className="btn-small" onClick={() => setAmount(String(suggestion.suggestedAmount))}>Use this amount</button>
            </div>
          )}

          <label>Notes</label>
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} />
          <button className="btn-primary" type="submit">Submit Request</button>
        </form>
      )}

      {inbox.length > 0 && (
        <div className="panel">
          <h2>Approval Inbox {isAccounts ? '(Accounts)' : '(Your direct reports)'}</h2>
          <table className="data-table">
            <thead>
              <tr><th>Employee</th><th>Tour Plan</th><th>Amount</th><th>Status</th><th>Action</th></tr>
            </thead>
            <tbody>
              {inbox.map((a) => (
                <tr key={a.advanceRequestId}>
                  <td>{a.employeeName}</td>
                  <td>{a.tourPlanTitle}</td>
                  <td>₹{a.requestedAmount.toLocaleString('en-IN')}</td>
                  <td><span className={`badge badge-${a.status.toLowerCase()}`}>{a.status}</span></td>
                  <td className="actions-cell">
                    {a.status === 'ApprovedByAccounts' && isAccounts ? (
                      <button className="btn-small" onClick={() => disburse(a)}>Disburse</button>
                    ) : (
                      <>
                        <button className="btn-small" onClick={() => decide(a, true)}>Approve</button>
                        <button className="btn-small btn-danger" onClick={() => decide(a, false)}>Reject</button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {isSales && (
        <div className="panel">
          <h2>My Advance Requests</h2>
          <table className="data-table">
            <thead>
              <tr><th>Tour Plan</th><th>Amount</th><th>Status</th><th>Disbursement</th></tr>
            </thead>
            <tbody>
              {mine.map((a) => (
                <tr key={a.advanceRequestId}>
                  <td>{a.tourPlanTitle}</td>
                  <td>₹{a.requestedAmount.toLocaleString('en-IN')}</td>
                  <td><span className={`badge badge-${a.status.toLowerCase()}`}>{a.status}</span></td>
                  <td>{a.disbursement ? `${a.disbursement.disbursementMode} · ₹${a.disbursement.amount.toLocaleString('en-IN')}` : '—'}</td>
                </tr>
              ))}
              {mine.length === 0 && <tr><td colSpan={4} className="empty-row">No advance requests yet.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
