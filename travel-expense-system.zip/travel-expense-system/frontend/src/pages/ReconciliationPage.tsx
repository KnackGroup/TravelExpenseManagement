import { useEffect, useState } from 'react';
import { apiClient, apiErrorMessage } from '../api/client';
import type { TripFinancialSummary } from '../api/types';

export default function ReconciliationPage() {
  const [rows, setRows] = useState<TripFinancialSummary[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiClient.get<TripFinancialSummary[]>('/api/reports/trip-summary')
      .then((r) => setRows(r.data))
      .catch((e) => setError(apiErrorMessage(e)));
  }, []);

  return (
    <div>
      <h1>Reconciliation Report</h1>
      <p className="subtitle">Advance disbursed vs. expense claimed vs. expense approved vs. tour outcome, per trip.</p>
      {error && <div className="error-box">{error}</div>}

      <table className="data-table">
        <thead>
          <tr>
            <th>Employee</th><th>Role</th><th>Channel</th><th>Trip</th><th>Dates</th><th>Status</th>
            <th>Advance</th><th>Claimed</th><th>Approved</th><th>Settlement</th><th>Exceptions</th><th>Daily Reports</th><th>Last Outcome</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.tourPlanId}>
              <td>{r.employeeName}</td>
              <td>{r.roleName}</td>
              <td>{r.channelName}</td>
              <td>{r.title}</td>
              <td>{r.startDate} → {r.endDate}</td>
              <td><span className={`badge badge-${r.tourPlanStatus.toLowerCase()}`}>{r.tourPlanStatus}</span></td>
              <td>₹{r.totalAdvanceDisbursed.toLocaleString('en-IN')}</td>
              <td>₹{r.totalExpenseClaimed.toLocaleString('en-IN')}</td>
              <td>₹{r.totalExpenseApproved.toLocaleString('en-IN')}</td>
              <td className={r.settlementAmount > 0 ? 'text-warn' : r.settlementAmount < 0 ? 'text-neg' : ''}>
                {r.settlementAmount > 0
                  ? `Pay employee ₹${r.settlementAmount.toLocaleString('en-IN')}`
                  : r.settlementAmount < 0
                    ? `Refund due ₹${Math.abs(r.settlementAmount).toLocaleString('en-IN')}`
                    : 'Settled'}
              </td>
              <td>{r.hasPolicyExceptions ? <span className="tag tag-exception">Yes</span> : 'No'}</td>
              <td>{r.dailyReportsSubmitted}</td>
              <td>{r.lastOutcomeSummary ?? '—'}</td>
            </tr>
          ))}
          {rows.length === 0 && <tr><td colSpan={13} className="empty-row">No trips in view yet.</td></tr>}
        </tbody>
      </table>
    </div>
  );
}
