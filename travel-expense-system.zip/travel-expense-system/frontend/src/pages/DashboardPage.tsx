import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { apiClient, apiErrorMessage } from '../api/client';
import { useAuth } from '../context/AuthContext';
import PolicyAssistant from '../components/PolicyAssistant';
import MyNotificationPreferences from '../components/MyNotificationPreferences';
import type { PendingPolicyException, TripFinancialSummary } from '../api/types';

export default function DashboardPage() {
  const { employee } = useAuth();
  const [trips, setTrips] = useState<TripFinancialSummary[]>([]);
  const [exceptions, setExceptions] = useState<PendingPolicyException[]>([]);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([
      apiClient.get<TripFinancialSummary[]>('/api/reports/trip-summary'),
      apiClient.get<PendingPolicyException[]>('/api/reports/pending-exceptions'),
    ])
      .then(([tripsRes, excRes]) => {
        setTrips(tripsRes.data);
        setExceptions(excRes.data);
      })
      .catch((err) => setError(apiErrorMessage(err)));
  }, []);

  const totalAdvance = trips.reduce((sum, t) => sum + t.totalAdvanceDisbursed, 0);
  const totalApproved = trips.reduce((sum, t) => sum + t.totalExpenseApproved, 0);
  const openTrips = trips.filter((t) => t.tourPlanStatus !== 'Closed').length;

  return (
    <div>
      <h1>Welcome, {employee?.fullName}</h1>
      <p className="subtitle">{employee?.roleName}{employee?.channelName ? ` · ${employee.channelName} channel` : ''}</p>

      {error && <div className="error-box">{error}</div>}

      <div className="cards-row">
        <div className="stat-card">
          <div className="stat-value">{trips.length}</div>
          <div className="stat-label">Trips in view</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{openTrips}</div>
          <div className="stat-label">Open trips</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">₹{totalAdvance.toLocaleString('en-IN')}</div>
          <div className="stat-label">Advance disbursed</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">₹{totalApproved.toLocaleString('en-IN')}</div>
          <div className="stat-label">Expense approved</div>
        </div>
        <div className="stat-card stat-card--warn">
          <div className="stat-value">{exceptions.length}</div>
          <div className="stat-label">Pending policy exceptions</div>
        </div>
      </div>

      <div className="panel">
        <h2>Quick links</h2>
        <div className="quick-links">
          <Link to="/tour-plans">Plan a new tour</Link>
          <Link to="/advances">Request / approve advances</Link>
          <Link to="/expense-reports">Submit / review expenses</Link>
          <Link to="/daily-reports">Log today's field report</Link>
          <Link to="/reconciliation">Full reconciliation report</Link>
        </div>
      </div>

      {exceptions.length > 0 && (
        <div className="panel">
          <h2>Pending policy exceptions needing your decision</h2>
          <table className="data-table">
            <thead>
              <tr>
                <th>Employee</th>
                <th>Category</th>
                <th>Date</th>
                <th>Claimed</th>
                <th>Cap</th>
                <th>Reason</th>
              </tr>
            </thead>
            <tbody>
              {exceptions.map((ex) => (
                <tr key={ex.expenseLineItemId} className="row-exception">
                  <td>{ex.employeeName}</td>
                  <td>{ex.categoryName}</td>
                  <td>{ex.expenseDate}</td>
                  <td>₹{ex.claimedAmount.toLocaleString('en-IN')}</td>
                  <td>{ex.policyCapAmountApplied != null ? `₹${ex.policyCapAmountApplied.toLocaleString('en-IN')}` : '—'}</td>
                  <td>{ex.exceptionReason}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <Link to="/expense-reports">Go review &amp; decide →</Link>
        </div>
      )}

      <PolicyAssistant />
      <MyNotificationPreferences />
    </div>
  );
}
