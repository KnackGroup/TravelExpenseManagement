import { useEffect, useState } from 'react';
import { apiClient, apiErrorMessage } from '../api/client';
import type { DailyReport, TourPlan, TripSummaryResult } from '../api/types';

export default function DailyReportsPage() {
  const [tourPlans, setTourPlans] = useState<TourPlan[]>([]);
  const [tourPlanId, setTourPlanId] = useState<number | ''>('');
  const [reports, setReports] = useState<DailyReport[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [summary, setSummary] = useState<TripSummaryResult | null>(null);
  const [summaryBusy, setSummaryBusy] = useState(false);

  const [reportDate, setReportDate] = useState(new Date().toISOString().slice(0, 10));
  const [visited, setVisited] = useState('');
  const [work, setWork] = useState('');
  const [outcome, setOutcome] = useState('');
  const [nextPlan, setNextPlan] = useState('');

  useEffect(() => {
    apiClient.get<TourPlan[]>('/api/tour-plans').then((r) => setTourPlans(r.data));
  }, []);

  useEffect(() => {
    setSummary(null);
    if (!tourPlanId) { setReports([]); return; }
    apiClient.get<DailyReport[]>(`/api/daily-reports/by-tour-plan/${tourPlanId}`).then((r) => setReports(r.data));
  }, [tourPlanId]);

  async function generateSummary() {
    if (!tourPlanId) return;
    setSummaryBusy(true);
    try {
      const res = await apiClient.get<TripSummaryResult>(`/api/ai/tour-plans/${tourPlanId}/summary`);
      setSummary(res.data);
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setSummaryBusy(false);
    }
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await apiClient.post('/api/daily-reports', {
        tourPlanId,
        reportDate,
        visitedLocations: visited,
        workSummary: work,
        outcomeSummary: outcome,
        nextDayPlan: nextPlan,
      });
      setVisited(''); setWork(''); setOutcome(''); setNextPlan('');
      const r = await apiClient.get<DailyReport[]>(`/api/daily-reports/by-tour-plan/${tourPlanId}`);
      setReports(r.data);
    } catch (err) {
      setError(apiErrorMessage(err));
    }
  }

  return (
    <div>
      <h1>Daily Tour Reports</h1>
      {error && <div className="error-box">{error}</div>}

      <label>Tour Plan</label>
      <select value={tourPlanId} onChange={(e) => setTourPlanId(Number(e.target.value))}>
        <option value="">Select…</option>
        {tourPlans.map((p) => <option key={p.tourPlanId} value={p.tourPlanId}>{p.title} ({p.startDate} → {p.endDate})</option>)}
      </select>

      {tourPlanId && (
        <form className="panel" onSubmit={submit}>
          <h2>Log today's report</h2>
          <div className="form-grid">
            <div>
              <label>Report Date</label>
              <input type="date" value={reportDate} onChange={(e) => setReportDate(e.target.value)} required />
            </div>
            <div>
              <label>Visited Locations</label>
              <input value={visited} onChange={(e) => setVisited(e.target.value)} />
            </div>
          </div>
          <label>Work Summary</label>
          <textarea value={work} onChange={(e) => setWork(e.target.value)} rows={2} />
          <label>Outcome Summary</label>
          <textarea value={outcome} onChange={(e) => setOutcome(e.target.value)} rows={2} />
          <label>Next Day Plan</label>
          <textarea value={nextPlan} onChange={(e) => setNextPlan(e.target.value)} rows={2} />
          <button className="btn-primary" type="submit">Save Daily Report</button>
        </form>
      )}

      {tourPlanId && (
        <div className="panel">
          <div className="page-header">
            <h2>Submitted daily reports</h2>
            <button className="btn-small" onClick={generateSummary} disabled={summaryBusy}>
              {summaryBusy ? 'Generating…' : '✨ Generate trip outcome summary'}
            </button>
          </div>
          {summary && (
            <div className={`ai-summary-box ${summary.aiGenerated ? '' : 'ai-summary-box--fallback'}`}>
              {!summary.aiGenerated && <div className="ai-summary-label">Extractive summary (no AI provider configured)</div>}
              {summary.summary}
            </div>
          )}
          <table className="data-table">
            <thead><tr><th>Date</th><th>Visited</th><th>Work Summary</th><th>Outcome</th><th>Next Plan</th></tr></thead>
            <tbody>
              {reports.map((r) => (
                <tr key={r.dailyTourReportId}>
                  <td>{r.reportDate}</td>
                  <td>{r.visitedLocations}</td>
                  <td>{r.workSummary}</td>
                  <td>{r.outcomeSummary}</td>
                  <td>{r.nextDayPlan}</td>
                </tr>
              ))}
              {reports.length === 0 && <tr><td colSpan={5} className="empty-row">No daily reports yet for this trip.</td></tr>}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
