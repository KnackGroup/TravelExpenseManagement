import { useEffect, useState } from 'react';
import { apiClient, apiErrorMessage } from '../api/client';
import type { AiSettings } from '../api/types';

export default function AdminAiSettingsPage() {
  const [settings, setSettings] = useState<AiSettings | null>(null);
  const [newApiKey, setNewApiKey] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    apiClient.get<AiSettings>('/api/ai/settings').then((r) => setSettings(r.data));
  }, []);

  async function save(e: React.FormEvent) {
    e.preventDefault();
    if (!settings) return;
    setError(null);
    setMessage(null);
    try {
      await apiClient.put('/api/ai/settings', { ...settings, newApiKey: newApiKey || null });
      setNewApiKey('');
      setMessage('AI settings saved.');
    } catch (err) {
      setError(apiErrorMessage(err));
    }
  }

  if (!settings) return <div className="page-loading">Loading…</div>;

  return (
    <div>
      <h1>Admin · AI Settings</h1>
      <p className="subtitle">
        Risk scoring, anomaly detection, advance suggestions, and the policy assistant work right now with no
        configuration here - they're computed straight from your policy and trip data. Adding a provider below
        additionally unlocks receipt-photo scanning, natural-language tour plan entry, and AI-written trip summaries.
      </p>

      {error && <div className="error-box">{error}</div>}
      {message && <div className="tag tag-ok" style={{ display: 'inline-block', marginBottom: 16 }}>{message}</div>}

      <div className="panel">
        <form onSubmit={save}>
          <div className="form-grid">
            <div>
              <label>Enabled</label>
              <select value={settings.isEnabled ? 'yes' : 'no'} onChange={(e) => setSettings({ ...settings, isEnabled: e.target.value === 'yes' })}>
                <option value="no">Off</option>
                <option value="yes">On</option>
              </select>
            </div>
            <div>
              <label>Provider</label>
              <select value={settings.provider} onChange={(e) => setSettings({ ...settings, provider: e.target.value as AiSettings['provider'] })}>
                <option value="None">None</option>
                <option value="OpenAI">OpenAI</option>
                <option value="AzureOpenAI">Azure OpenAI</option>
              </select>
            </div>
            {settings.provider === 'AzureOpenAI' && (
              <div>
                <label>Azure endpoint</label>
                <input placeholder="https://your-resource.openai.azure.com" value={settings.apiEndpoint ?? ''} onChange={(e) => setSettings({ ...settings, apiEndpoint: e.target.value })} />
              </div>
            )}
            <div>
              <label>Model {settings.provider === 'AzureOpenAI' ? '(deployment name)' : '(e.g. gpt-4o-mini)'}</label>
              <input value={settings.model ?? ''} onChange={(e) => setSettings({ ...settings, model: e.target.value })} />
            </div>
            <div>
              <label>API key {settings.hasApiKey && <span className="tag tag-ok">saved</span>}</label>
              <input type="password" placeholder={settings.hasApiKey ? 'Leave blank to keep current' : ''} value={newApiKey} onChange={(e) => setNewApiKey(e.target.value)} />
            </div>
          </div>
          <div style={{ marginTop: 12 }}>
            <button className="btn-primary" type="submit">Save AI Settings</button>
          </div>
        </form>
      </div>
    </div>
  );
}
