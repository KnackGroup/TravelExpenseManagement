export interface EmployeeSummary {
  employeeId: number;
  employeeCode: string;
  fullName: string;
  email: string;
  roleId: number;
  roleCode: string;
  roleName: string;
  roleType: 'Sales' | 'Accounts' | 'Admin';
  channelId: number | null;
  channelName: string | null;
  hierarchyLevel: number | null;
  managerEmployeeId: number | null;
  managerName: string | null;
}

export interface Channel {
  channelId: number;
  channelCode: string;
  channelName: string;
  isActive: boolean;
}

export interface Role {
  roleId: number;
  channelId: number | null;
  channelName: string | null;
  roleCode: string;
  roleName: string;
  hierarchyLevel: number | null;
  roleType: string;
  isActive: boolean;
}

export interface EmployeeListItem {
  employeeId: number;
  employeeCode: string;
  fullName: string;
  email: string;
  roleCode: string;
  roleName: string;
  channelName: string | null;
  managerName: string | null;
  isActive: boolean;
}

export interface ExpenseCategory {
  expenseCategoryId: number;
  categoryCode: string;
  categoryName: string;
  isTicketCategory: boolean;
}

export interface PolicyCap {
  policyCapId: number;
  roleId: number;
  roleCode: string;
  roleName: string;
  channelName: string | null;
  expenseCategoryId: number;
  categoryCode: string;
  categoryName: string;
  isAllowed: boolean;
  maxAmountPerDay: number | null;
  maxAmountPerBooking: number | null;
  maxClass: string | null;
  currency: string;
  effectiveFrom: string;
  effectiveTo: string | null;
}

export interface TourPlanStop {
  visitDate: string;
  location: string;
  stateOrCountry: string | null;
  purposeNotes: string | null;
}

export interface TourPlan {
  tourPlanId: number;
  employeeId: number;
  employeeName: string;
  channelId: number;
  channelName: string;
  title: string;
  purposeOfVisit: string | null;
  startDate: string;
  endDate: string;
  status: string;
  stops: TourPlanStop[];
  createdAt: string;
}

export interface AdvanceApproval {
  advanceApprovalId: number;
  approverName: string;
  approvalStage: 'Superior' | 'Accounts';
  decision: 'Approved' | 'Rejected';
  approvedAmount: number | null;
  comments: string | null;
  decidedAt: string;
}

export interface AdvanceDisbursement {
  disbursementMode: 'Cash' | 'BankTransfer';
  amount: number;
  referenceNo: string | null;
  disbursedByName: string;
  disbursedAt: string;
}

export interface AdvanceRequestDto {
  advanceRequestId: number;
  tourPlanId: number;
  tourPlanTitle: string;
  employeeId: number;
  employeeName: string;
  requestedAmount: number;
  currency: string;
  requestNotes: string | null;
  status: string;
  createdAt: string;
  approvals: AdvanceApproval[];
  disbursement: AdvanceDisbursement | null;
}

export interface ExpenseLineItem {
  expenseLineItemId: number;
  expenseDate: string;
  expenseCategoryId: number;
  categoryName: string;
  description: string | null;
  claimedAmount: number;
  currency: string;
  policyCapAmountApplied: number | null;
  isPolicyException: boolean;
  exceptionReason: string | null;
  lineStatus: string;
  approvedAmount: number | null;
  approverComments: string | null;
}

export interface ExpenseReport {
  expenseReportId: number;
  tourPlanId: number;
  tourPlanTitle: string;
  employeeId: number;
  employeeName: string;
  submittedAt: string | null;
  status: string;
  totalClaimedAmount: number;
  totalApprovedAmount: number | null;
  hasPolicyExceptions: boolean;
  lineItems: ExpenseLineItem[];
}

export interface DailyReport {
  dailyTourReportId: number;
  tourPlanId: number;
  employeeId: number;
  employeeName: string;
  reportDate: string;
  visitedLocations: string | null;
  workSummary: string | null;
  outcomeSummary: string | null;
  nextDayPlan: string | null;
  createdAt: string;
}

export interface TripFinancialSummary {
  tourPlanId: number;
  employeeId: number;
  employeeName: string;
  roleName: string;
  channelName: string;
  title: string;
  startDate: string;
  endDate: string;
  tourPlanStatus: string;
  totalAdvanceDisbursed: number;
  totalExpenseClaimed: number;
  totalExpenseApproved: number;
  hasPolicyExceptions: boolean;
  settlementAmount: number;
  dailyReportsSubmitted: number;
  lastOutcomeSummary: string | null;
}

export interface PendingPolicyException {
  expenseLineItemId: number;
  expenseReportId: number;
  tourPlanId: number;
  employeeId: number;
  employeeName: string;
  categoryName: string;
  expenseDate: string;
  claimedAmount: number;
  policyCapAmountApplied: number | null;
  exceptionReason: string | null;
  lineStatus: string;
}

// ---------- Notifications ----------

export interface EmailSettings {
  isEnabled: boolean;
  smtpHost: string;
  smtpPort: number;
  enableSsl: boolean;
  authMode: 'Basic' | 'OAuth2';
  smtpUsername: string | null;
  hasSecret: boolean;
  oAuthTenantId: string | null;
  fromAddress: string;
  fromName: string;
}

export interface EmailTemplate {
  emailTemplateId: number;
  eventType: string;
  description: string | null;
  subject: string;
  bodyHtml: string;
  isEnabled: boolean;
  updatedAt: string;
}

export interface NotificationPreference {
  eventType: string;
  description: string | null;
  globallyEnabled: boolean;
  isEnabledForMe: boolean;
}

// ---------- AI ----------

export interface AiSettings {
  isEnabled: boolean;
  provider: 'None' | 'OpenAI' | 'AzureOpenAI';
  apiEndpoint: string | null;
  hasApiKey: boolean;
  model: string | null;
}

export interface AiFeatureStatus {
  isEnabled: boolean;
  provider: string;
}

export interface ExceptionRiskAssessment {
  expenseLineItemId: number;
  riskLevel: 'Low' | 'Medium' | 'High';
  recommendation: string;
  rationale: string;
  overagePercent: number | null;
  employeeExceptionCountLast90Days: number;
  employeeExceptionApprovalRate: number | null;
}

export interface AdvanceSuggestion {
  tourPlanId: number;
  suggestedAmount: number;
  currency: string;
  basis: string;
  comparableTripsCount: number;
}

export interface AnomalyFlag {
  expenseLineItemId: number;
  flagType: string;
  severity: 'Low' | 'Medium' | 'High';
  message: string;
}

export interface PolicyAnswer {
  answer: string;
  grounded: boolean;
}

export interface ReceiptParseResult {
  isAvailable: boolean;
  amount: number | null;
  expenseDate: string | null;
  vendor: string | null;
  suggestedCategoryCode: string | null;
  confidence: number | null;
  notes: string | null;
}

export interface ParsedTourPlanStop {
  visitDate: string | null;
  location: string;
  stateOrCountry: string | null;
  purposeNotes: string | null;
}

export interface ParseTourPlanTextResult {
  isAvailable: boolean;
  title: string | null;
  purposeOfVisit: string | null;
  startDate: string | null;
  endDate: string | null;
  stops: ParsedTourPlanStop[];
  notes: string | null;
}

export interface TripSummaryResult {
  aiGenerated: boolean;
  summary: string;
}
