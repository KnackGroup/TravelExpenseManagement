# Sales Travel &amp; Expense Management System

A full-stack app for the sales tour-plan → advance → approval → expense-report → policy-exception →
reconciliation workflow, built for a two-channel (Domestic / Export) sales organization with a
fully dynamic, admin-configurable hierarchy and travel policy.

- **Frontend:** React 19 + TypeScript + Vite (`/frontend`)
- **API:** ASP.NET Core 8 Web API + Entity Framework Core (`/api`)
- **Database:** SQL Server 2022 (`/db/schema.sql`, `/db/seed.sql`)
- **Orchestration:** Docker Compose (SQL Server + API + frontend, one command)

On top of the core workflow, the system also ships: AI decision support (risk scoring, anomaly
detection, advance suggestions, a grounded policy assistant - all with no external API key), an
optional bring-your-own-key layer for receipt-photo scanning / natural-language tour plan entry /
AI trip summaries, and fully dynamic Outlook/Microsoft 365 email notifications. See §8 and §9, and
the [feature roadmap](#10-feature-roadmap) for what's built vs. what's proposed next.

---

## 1. What this solves

- **Dynamic hierarchy.** Domestic is General Manager → Regional Manager → Area Manager. Export is
  General Manager → Continent Manager → Regional Manager → Area Manager. Neither chain is
  hard-coded: `Channels` and `Roles` are data, and each employee's actual approval chain is their
  own `ManagerEmployeeId` — so re-orgs, renamed roles, or a 5th channel are all just data changes
  from **Admin → Hierarchy**.
- **Dynamic travel policy.** One table (`PolicyCaps`) holds, per role and per expense category:
  whether it's allowed at all (this is how "Area Manager cannot book flights" is expressed),
  the max amount per day, the max amount per booking (for flights/trains), and a max travel class.
  Editable any time from **Admin → Policy**, with full history preserved.
  Sample seeded policy: Area Manager — no flights, train capped; Regional Manager — flights and
  trains both allowed; Continent Manager (Export only) — higher caps between RM and GM; General
  Manager — highest caps, local conveyance capped at "Cab" tier.
- **Tour plan → advance → approval → disbursement.** An employee files a tour plan, requests an
  advance against it, their direct manager approves ("Superior" stage), Accounts approves and
  records the payout (cash or bank transfer).
- **Expense report with policy-variance highlighting.** Every submitted line item is checked
  live (in the UI, as you type) and again authoritatively on the server against the employee's
  role policy. In-policy lines are auto-approved on submit. Over-cap or disallowed lines are
  flagged as exceptions **but the report still submits** — exceptions are routed to the employee's
  reporting manager, who explicitly approves or rejects each one.
- **Daily tour report.** A short field summary (visited locations, work done, outcome, next-day
  plan) loggable once per day per trip.
- **Reconciliation report.** Per trip: advance disbursed vs. expense claimed vs. expense approved
  vs. settlement amount (refund owed, or additional payment due) vs. tour outcome — backed by a
  SQL view (`vw_TripFinancialSummary`) so the math lives in one auditable place.

## 2. Project layout

```
db/
  schema.sql        Full T-SQL schema (source of truth) - run this first
  seed.sql          Demo hierarchy, policy caps, and one sample end-to-end trip
  init.sh           Applies schema.sql + seed.sql (used by the db-init container)
api/
  TravelExpense.Api/
    Data/            EF Core entities + DbContext (maps onto db/schema.sql; no EF migrations -
                      the SQL file is the single source of truth for the schema)
    Auth/            JWT issuing + bcrypt password hashing
    Services/        PolicyEngine (variance checks), ApprovalRoutingService (hierarchy lookups)
    Services/Notifications/  Dynamic SMTP sender (Basic + OAuth2), template rendering, outbox
                              queue + background dispatcher, daily digest/reminder automation
    Services/Ai/     AI-lite insight engine (no key needed) + pluggable OpenAI/Azure OpenAI
                     provider abstraction for the optional bring-your-own-key features
    Services/Security/  Encrypts SMTP passwords / API keys at rest (ASP.NET Data Protection)
    Controllers/      Auth, Hierarchy, Policy, TourPlans, Advances, ExpenseReports, DailyReports,
                      Reports, Notifications (email settings/templates/preferences), Ai
frontend/
  src/
    api/             Axios client + TypeScript types matching the API DTOs
    context/         AuthContext (JWT session)
    pages/           One page per feature area
docker-compose.yml   SQL Server + schema/seed init + API + frontend, wired together
```

## 3. Running it

**Prerequisites:** Docker (with Compose) on the machine you run this on. This project was built
and code-reviewed in a sandbox that had no NuGet registry access, so the .NET API's package
restore/build was **not** verified there — the frontend's TypeScript build *was* verified
(`tsc --noEmit` and `npm run build` both pass cleanly). Once you run this on a machine with normal
internet access, `docker compose build` will restore the standard, well-known NuGet packages used
(EF Core, JWT bearer auth, Swashbuckle, BCrypt.Net-Next, MailKit/MimeKit for SMTP,
Microsoft.Identity.Client for OAuth2) and compile the API — if anything doesn't line up, it'll
most likely be a minor package-version pin, easy to bump in `TravelExpense.Api.csproj`. The C#
added for notifications/AI was reviewed by hand (including an empirical check of ASP.NET Core's
implicit global usings) since `dotnet build` itself couldn't run in this sandbox, but treat a
first build on your machine as the real verification step.

```bash
cp .env.example .env
# edit .env - at minimum set a real SA_PASSWORD and JWT_SIGNING_KEY

docker compose up --build
```

This brings up, in order: SQL Server → schema + seed data applied → API on
`http://localhost:8080` (Swagger at `/swagger`) → frontend on `http://localhost:5173`.

To run the frontend or API outside Docker during development:

```bash
# API
cd api/TravelExpense.Api
dotnet restore
dotnet run
# edit appsettings.Development.json or use user-secrets for the connection string / JWT key

# Frontend
cd frontend
cp .env.example .env    # VITE_API_BASE_URL=http://localhost:8080 (or 5000/5001 for `dotnet run`)
npm install
npm run dev
```

## 4. Demo logins

Seeded by `db/seed.sql`, password **`Passw0rd!`** for all:

| Email | Role |
|---|---|
| admin@knackpackaging.com | System Administrator (hierarchy/policy config) |
| accounts@knackpackaging.com | Accounts (advance approval + disbursement) |
| gm.domestic@knackpackaging.com | GM, Domestic |
| rm.north@knackpackaging.com | Regional Manager, Domestic (reports to GM Domestic) |
| am.delhi@knackpackaging.com | Area Manager, Domestic (reports to RM North) |
| gm.export@knackpackaging.com | GM, Export |
| cm.mea@knackpackaging.com | Continent Manager, Export (reports to GM Export) |
| rm.gulf@knackpackaging.com | Regional Manager, Export (reports to CM MEA) |
| am.uae@knackpackaging.com | Area Manager, Export (reports to RM Gulf) |

A sample tour plan + fully-disbursed advance is pre-seeded under `am.delhi@knackpackaging.com` so
you can log in and immediately submit an expense report against it (try an amount above the seeded
Area Manager food/hotel caps, or a Flight line item, to see the exception highlighting).

## 5. How the policy-exception workflow works end to end

1. Employee submits an expense report with one or more line items.
2. Server (`PolicyEngine`) looks up the effective `PolicyCap` for the employee's role + category
   as of the expense date. Ticket categories (Flight/Train) are checked against the per-booking
   cap; everything else against the per-day cap. A category with `IsAllowed = 0` (e.g. Flight for
   an Area Manager) is always an exception, regardless of amount.
3. In-policy lines are saved as `Approved` immediately (no discretion needed). Over-cap or
   disallowed lines are saved as `Pending` with `IsPolicyException = 1` and a human-readable
   reason — **the report still submits successfully**, nothing blocks it.
4. The employee's direct manager sees these under **Expense Reports → "Reports awaiting your
   decision"** and approves or rejects each exception line individually (can also partially
   approve, i.e. approve a lower amount than claimed).
5. Once every line has a decision, the report's overall status resolves to `Approved`,
   `PartiallyApproved`, or `Rejected`, and `TotalApprovedAmount` is recomputed.

## 6. Extending it

- **New channel or hierarchy level:** Admin → Hierarchy → add a `Role` with the right
  `ChannelId`/`HierarchyLevel`, then add/reassign `Employees` under it. No code change.
- **New expense category or changed cap:** Admin → Policy. Caps are date-ranged
  (`EffectiveFrom`/`EffectiveTo`), so raising the GM hotel cap next quarter doesn't erase this
  quarter's policy - it's preserved for audit.
- **Email notifications and AI decision support are implemented** (§8, §9). Multi-currency FX,
  pagination, refresh tokens, a formal audit log, and role-based field-level permissions are
  still **not** implemented - this remains a solid, working foundation, not a finished enterprise
  product. The schema (`PolicyCapAmountApplied` snapshots, `AdvanceApprovals`/`ExpenseLineItems`
  history rows) is deliberately audit-friendly so these stay additive, not restructuring, work.

## 7. Security notes before any real deployment

- Change `JWT_SIGNING_KEY` and `SA_PASSWORD` in `.env` - the checked-in values are placeholders.
- Put this behind HTTPS (a reverse proxy like Caddy/nginx with a real certificate) - the compose
  file here is plain HTTP, meant for local/internal evaluation.
- JWTs are long-lived (8h) with no refresh flow - fine for a pilot, worth hardening
  (shorter expiry + refresh tokens) before a wider rollout.

## 8. Configuring Outlook / Microsoft 365 email

Nothing here is set via environment variables or config files - it's all runtime settings under
**Admin → Notifications**, editable by an Admin user without a redeploy. That's deliberate: SMTP
credentials, per-event templates, and the global/per-employee send toggles are exactly the kind of
thing that changes after go-live (a new mailbox, a reworded template, someone asking to be taken
off a particular email) and shouldn't need a code change or restart.

**What ships:**

- Ten workflow triggers, seeded with default templates in `db/seed.sql`: tour plan submitted,
  advance requested, advance approved/rejected, advance disbursed, expense report submitted,
  policy exception raised, expense report decided, a same-day daily-report reminder, and a daily
  pending-approval digest.
- Two independent on/off switches per event: a global enable/disable per event type
  (**Admin → Notifications → Templates**), and a personal opt-out any employee can set for
  themselves (**Dashboard → notification preferences widget**) - so a global "advance disbursed"
  email can stay on for everyone while one person mutes it for themselves.
- Templates are plain HTML with `{{Placeholder}}` tokens (`{{EmployeeName}}`, `{{Amount}}`,
  `{{TourPlanTitle}}`, `{{AppUrl}}`, etc.) - editable in the admin UI, not hardcoded strings.
- Outgoing mail goes through an outbox queue (`EmailOutbox` table), flushed by a background
  service every 20 seconds with automatic retry (up to 5 attempts) - so a triggering request
  (submitting an expense report, approving an advance) never waits on SMTP, and a transient mail
  server hiccup doesn't lose the notification.

**Setup - Basic auth (simplest, if your tenant still allows it):**

1. Admin → Notifications → Email Settings.
2. Host `smtp.office365.com`, port `587`, SSL on, Auth mode **Basic**.
3. Username = the sending mailbox's address; password = an app password for that mailbox
   (Exchange admin center → the mailbox → **Manage email apps** - regular account passwords
   won't work if MFA is enforced, which it should be).
4. Save, then use **Send test email** to confirm before relying on it.

Microsoft has been steadily disabling Basic auth for SMTP AUTH tenant-wide; if it's off for you,
use OAuth2 instead.

**Setup - OAuth2 (Microsoft's recommended path):**

1. In Azure AD, register an application (or reuse an existing one) and create a client secret for it.
2. Grant it application permission to send as the specific mailbox, via Exchange Online PowerShell:
   ```powershell
   Connect-ExchangeOnline
   New-ServicePrincipal -AppId <your-app-client-id> -ObjectId <app-registration-object-id>
   New-ManagementScope -Name "TE-SendAs-Scope" -RecipientRestrictionFilter "PrimarySmtpAddress -eq 'noreply@yourtenant.com'"
   New-ManagementRoleAssignment -Role "SMTP.SendAsApp" -App <your-app-client-id> -CustomResourceScope "TE-SendAs-Scope"
   ```
   (Restrict the scope to just the sending mailbox - don't grant tenant-wide send-as to the app.)
3. Admin → Notifications → Email Settings: Auth mode **OAuth2**, Username = the app's **client ID**,
   Secret = the **client secret** from step 1, OAuth Tenant ID = your Azure AD tenant ID,
   From Address = the mailbox from step 2.
4. Save, then **Send test email**. The API acquires a token via MSAL's client-credentials flow
   (scope `https://outlook.office365.com/.default`) and authenticates SMTP with XOAUTH2 - no
   interactive login, no refresh token to manage.

Either way, the SMTP password / client secret is encrypted at rest (ASP.NET Core Data Protection)
before it's stored - never in plain text in the database. Re-saving the settings form without
retyping the secret keeps the one already stored.

## 9. Configuring AI features

Also all runtime settings, this time under **Admin → AI Settings** - and mostly there's nothing to
configure at all:

- **Always on, no key required:** exception risk scoring, duplicate/anomaly detection on expense
  reports, advance-amount suggestions, and a policy Q&A assistant. These are computed directly
  from your own hierarchy, policy, and trip data - deterministic, auditable, zero hallucination
  risk, which matters more than a generic LLM's fluency for "is this claim within policy."
- **Optional, needs a key:** receipt-photo scanning (auto-fills date/amount/vendor/category from
  a photo), natural-language tour plan entry ("3 days in Pune meeting distributors next week"),
  and AI-written trip summaries from daily reports. These work with either an OpenAI API key or
  an Azure OpenAI deployment - set Provider, Model (or Azure deployment name), and the API key
  under Admin → AI Settings. Until a key is added, each of these degrades to a clear "not
  configured yet, fill this in manually" state rather than erroring - the app is fully usable
  either way.

The API key is encrypted at rest the same way SMTP credentials are.

## 10. Feature roadmap

What's built now vs. what would make this closer to a globally-standard sales T&E platform
(multi-currency, SSO, mobile offline capture, ERP connectors, and more) is written up here:

**[Feature roadmap - Expense System Flight Plan](https://claude.ai/code/artifact/b3377416-2814-4f87-8e01-76482a03aece)**
